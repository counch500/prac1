"""
Common modules for MOOD.
"""