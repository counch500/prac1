"""
Client package for MOOD.
"""
